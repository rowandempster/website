
// You should complete this interface

//down_value(x, y) returns the address of the larger value 
//   that x and y point to, or NULL if the values are the same
//effects: may mutate the values of what x and y point to
int *down_value (int *x, int *y);
