
// This module provides a simple posn structure

struct posn {
	int x;
	int y;
};
