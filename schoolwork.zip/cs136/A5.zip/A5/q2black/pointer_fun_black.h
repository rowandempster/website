// Note: you do NOT have to modify this interface

// read_two(&n1, &n2) reads and stores natural numbers in n1 and n2.
//   See assignment for more details.
// requires: n1,n2 are not NULL

int read_two(int *n1, int *n2);
