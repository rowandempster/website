#include "testing-module.h"
#include "pantry.h"

int main(void) {
	interactive_pantry_test();
}