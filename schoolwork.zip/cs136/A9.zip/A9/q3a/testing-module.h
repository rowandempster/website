// interactive_pantry_test() reads input from the user in order to test the
//  pantry module.  (See the assignment files for a more detailed description).
// effects: text is read from input until EOF.
//          text is printed to the output.

void interactive_pantry_test(void);