// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work

// sign this statement by removing the line below and entering your name

// Name: Rowan Dempster
// login ID: R2DEMPST

// interface:

//Returns the the integer the user has entered if that integer
//   is non-negative, or -2 if that integer is negative. 
//   Otherwise, returns -1.
int readnat(void);

//Returns the the float the user has entered if that float
//   is non-negative, or -2 if that float is negative. 
//   Otherwise, returns -1.
float readnonnegfloat(void);
