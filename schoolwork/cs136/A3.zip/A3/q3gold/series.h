// this module provides series function(s)

// fibonacci(n) prints out first n fibonacci numbers
// requires: n >= 1
// effects: prints out a sequence
void fibonacci(int n);
