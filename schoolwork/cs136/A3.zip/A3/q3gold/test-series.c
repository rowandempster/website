// This is a very basic test program provided for you

#include "series.h"

int main(void) {
  fibonacci(8);
  fibonacci(27);
}
