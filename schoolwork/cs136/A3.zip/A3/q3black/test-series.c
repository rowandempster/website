// This is a very basic test program provided for you

#include "series.h"

int main(void) {
  collatz(6);
  collatz(17);
    
}
