// this module provides series function(s)

// collatz(n) prints out the collatz series starting with n
// requires: n >= 1
// effects: prints out a sequence
void collatz(int n);
